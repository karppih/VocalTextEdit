//
//  ViewController.swift
//  VocalTextEdit
//
//  Created by Helen Karppi on 8/6/17.
//  Copyright © 2017 Helen Karppi. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {
    
    let speechSynthesizer = NSSpeechSynthesizer()

    @IBOutlet var textView: NSTextView!
    
    var contents: String? {
        get {
            return textView.string
        }
        set {
            textView.string = newValue
        }
    }
    
    @IBAction func speakButtonClicked(_ sender: NSButton) {
        print("I should speak \(textView.string!)")
        if let contents = textView.string, !contents.isEmpty {
            speechSynthesizer.startSpeaking(contents)
        } else {
            speechSynthesizer.startSpeaking("The document is empty.")
        }
    }
    @IBAction func stopButtonClicked(_ sender: NSButton) {
        print("The Stop button was clicked")
        speechSynthesizer.stopSpeaking()
    }

}

